module.exports = async function sayHello(state, event) {
    event.reply('#!builtin_text-Welcome', { message: `Hello! I am SATYA-Ai. How can I assist you today?` });
    return state;
  };
  