const botpress = require('botpress');
const botpressClient = botpress.createClient({
  apiKey: 'bp_pat_E5LOiMBD8YvxFNtEaXA7CFbKPhXlnnwv2St6',
  baseUrl: 'https://api.botpress.com'
});

botpressClient.startConversation({
  botId: 'SATYA-AI',
  userId: 'user123',
  context: {}
}).then(conversation => {
  console.log('Conversation started:', conversation);
}).catch(error => {
  console.error('Error starting conversation:', error);
});
